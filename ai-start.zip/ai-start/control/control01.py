from tkinter.messagebox import showinfo
food_list = ['라면','짬뽕','우동'] #리스트
showinfo('hello', food_list)


