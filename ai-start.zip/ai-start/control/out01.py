import tkinter.messagebox as box

box.showinfo('저는 다이어로그 창입니다.', '안녕히가세요.')

n1 = 20
n2 = 10
box.showinfo('더한 값', n1 + n2)


































