# 기본 출력: 모니터
print('두번째 실습파일입니다.')

# 기본 입력: 키보드
name = input('이름을 입력: ') #alt+화살표: 이동
age = input('나이를 입력: ')
company = input('소속을 입력: ')

# 나이와 소속(edu)
print('당신이 입력한 이름은 ', name, '입니다.')
print('당신이 입력한 나이는 ', age, '입니다.')
print('당신이 입력한 소속은 ', company, '입니다.')