# print('문자 데이타')

good_rate = 2.5 #snake 표기법
normal_rate = 5 #계산 가능한 숫자로 인식: 기호X
bad_rate = 15.5
print('좋은 은행의 이자율은  ', good_rate)
money = 10000
print('좋은 은행의 이자는 ', money * good_rate)

tel = '01012345678'
sn = '99090920'
