total = 252

# 전체 인원: 252
# 5명씩 준다고 했을 때, 몇 명이나 줄 수 있는지?
print(total / 5)
print(total // 5)
print(total % 5)
